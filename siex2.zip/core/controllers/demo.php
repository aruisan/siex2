<?php

$nombre = $_POST['nombre'];
$fecha =  $_POST['fecha'];
$files = $_FILES["archivo"]["name"];

echo $_POST['metodo'];


?>