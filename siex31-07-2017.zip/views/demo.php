<?php
echo date('Y-m-d');
?>