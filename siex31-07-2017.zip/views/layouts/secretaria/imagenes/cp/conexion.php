<?php
	require_once('../../../../../../core/models/conexion.php');
		//confi de go daddy
		/*$conexion = new mysqli('localhost', 'aruisan', 'oskr1987', 'siex');
		if ($conexion->connect_error){

			die('Error en la conexion'.$conexion->connect_error);
		}*/

	$ruta_files = "../../../";
?>