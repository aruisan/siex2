<?php
 echo $_FILES["archivo"]["type"];
?>