
              <br><br>
                <form id="form-contactenos" class="text-danger">
                  <div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <label>NOMBE COMPLETO: </label>
                    <div class="input-group">
                      <span class="input-group-addon label-danger"><i class="fa fa-user-o text-white" aria-hidden="true"></i></span>
                      <input type="text" class="form-control input-danger" name="name" placeholder="Digita tu nombre">
                    </div>
                  </div>
                  <div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <label>CORREO ELECTRONICO: </label>
                    <div class="input-group">
                      <span class="input-group-addon label-danger"><i class="fa  fa-envelope-o text-white" aria-hidden="true"></i></span>
                      <input type="text" class="form-control bg-danger" name="email" placeholder="Digita el correo">
                    </div>
                  </div>
                  <div class="form-group col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <label>MENSAJE: </label>
                      <textarea class="form-control bg-danger" name="message" rows="5"></textarea>
                      <label>___________________________________________________________________________________
                      <label>               ALTA ESPECIALIDAD SAS
                      <label>Carrera 37 A 29 56 Int. 2207 El Poblado Medellin CEL 3208858086 - 3144836423
                      <label>Correo: info@altaespecialidad.co - luismoyar@hotmail.com 
                  </div>
                </form>